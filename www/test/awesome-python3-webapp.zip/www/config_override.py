'''
Override configurations.
'''

__author__ = 'George Zhang'

configs = {
	'db':{
		'host': '127.0.0.1'
	}
}